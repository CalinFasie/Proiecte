package com.example.PeopleM;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PeopleMApplication {

	public static void main(String[] args) {
		SpringApplication.run(PeopleMApplication.class, args);
	}

}
