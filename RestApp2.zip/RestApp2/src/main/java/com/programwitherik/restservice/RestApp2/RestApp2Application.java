package com.programwitherik.restservice.RestApp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(RestApp2Application.class, args);
	}

}
