package com.example.HelloWordMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWordMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
